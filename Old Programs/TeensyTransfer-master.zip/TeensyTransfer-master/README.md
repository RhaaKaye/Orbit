# TeensyTransfer
Teensy HID Transfer Tool 

Copy files from PC to a serial flash (connected to a Teensy)

Usage:
 - open Arduino, set USB-Mode to "Raw Hid"
 - load teensytransfertool.ino, compile, and flash it to the teensy
 
The gz - file contains the Linux-version, the *.zip the Windows-version

The .mac.zip file contains the Mac OS version

Documentation here:
https://forum.pjrc.com/threads/33859-TeensyTransfer?p=101306
